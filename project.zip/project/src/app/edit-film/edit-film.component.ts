import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../app.service';

@Component({
  selector: 'app-edit-film',
  templateUrl: './edit-film.component.html',
  styleUrls: ['./edit-film.component.scss']
})
export class EditFilmComponent implements OnInit, OnDestroy {
  private sub: any;
  id: number = 1;
  filmList = [];
  currentEditedFilm;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private appService: AppService) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number

      // In a real app: dispatch action to load the details here.
    });
    this.filmList = this.appService.getFilmList();
    this.currentEditedFilm = this.getEditedFilm();
    this.currentEditedFilm.releaseDate = new Date(this.currentEditedFilm.date).toISOString().substring(0, 10);
  }

  getEditedFilm() {
    return this.filmList.find((film) => film.id === this.id);

  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  onEdit(data) {
    if (data.form.status === 'VALID') {
      for (let i = 0; i < this.filmList.length; i++) {
        if (this.filmList[i].id === this.id) {
          this.filmList[i].title = data.form.value.title,
            this.filmList[i].directorName = data.form.value.directorName,
            this.filmList[i].date = data.form.value.releaseDate
        }
      }
      this.appService.filmList = this.filmList;
      this.router.navigate(['/home']);
    }
  }

  cancelEditing() {
    this.router.navigate(['/home']);
  }

}
