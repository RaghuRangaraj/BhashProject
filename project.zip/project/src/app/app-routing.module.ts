import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditFilmComponent } from './edit-film/edit-film.component';
import { FilmListComponent } from './film-list/film-list.component';

const routes: Routes = [
  { path: '', component: FilmListComponent },
  { path: 'home', redirectTo: ''},
  { path: 'edit-film/:id', component: EditFilmComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
