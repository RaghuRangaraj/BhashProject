import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AppService } from '../app.service';

@Component({
  selector: 'app-film-list',
  templateUrl: './film-list.component.html',
  styleUrls: ['./film-list.component.scss']
})
export class FilmListComponent implements OnInit {

  @ViewChild('addNewFilModal') addNewFilModal: ElementRef;

  filmList = [];

  constructor(private modalService: NgbModal,
    private appService: AppService) { }

  ngOnInit(): void {
    this.filmList = this.appService.getFilmList();
  }

  addNewFilm() {
    this.modalService.open(this.addNewFilModal, {
      keyboard: false,
      backdrop: 'static', centered: true
    });
  }

  addFilledData(data) {
    console.log(data);
    if (data.form.status === 'VALID') {
      this.filmList.push({
        id: this.filmList.length + 1,
        title: data.form.value.title,
        directorName: data.form.value.directorName,
        date: data.form.value.releaseDate
      });
      this.appService.filmList = this.filmList;
      this.modalService.dismissAll();
    } else {
      alert('Enter valus for all fields');
    }
  }

  cancelAdding() {
    this.modalService.dismissAll();
  }

}
