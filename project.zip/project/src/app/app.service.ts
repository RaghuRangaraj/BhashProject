import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  filmList = [{
    id: 1,
    title: 'Episode IV - A New Hope',
    directorName: 'George Lucas',
    date: 'May 25, 1977'
  }, {
    id: 2,
    title: 'Episode V - The Empire Strikes Back',
    directorName: 'Irvin Kershner',
    date: 'May 21, 1980'
  }, {
    id: 3,
    title: 'Episode VI - Return of the Jedi',
    directorName: 'Richard Marquand',
    date: 'May 25, 1983'
  }];

  constructor() { }

  getFilmList() {
    return this.filmList;
  }

  setFilmList(film) {
    this.filmList = film;
  }
}
